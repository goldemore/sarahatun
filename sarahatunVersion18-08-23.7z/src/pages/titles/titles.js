const titles = {
    home: 'Əsas | Sara Hatun',
    about: 'Haqqımızda | Sara Hatun',
    contact: 'Bizimlə Əlaqə | Sara Hatun',
    basket: 'Səbət | Sara Hatun',
    favourite: 'Favorilər | Sara Hatun',
    login: 'Login: | Sara Hatun',
    order: 'Sifarişlər | Sara Hatun',
    register: 'Qeydiyyat | Sara Hatun',
    basketPayment:'Ödəniş | Sara Hatun',
    
  };
  
  export default titles;